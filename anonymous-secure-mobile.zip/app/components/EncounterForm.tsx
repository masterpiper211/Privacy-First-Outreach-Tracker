import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { 
  RiskLevel, 
  EncounterFormData, 
  OBSERVED_CONDITIONS, 
  SERVICES_REQUESTED, 
  REFERRALS,
  Encounter,
} from '../lib/types';
import { generateAnonymousId } from '../lib/encounterService';
import { MultiSelect } from './MultiSelect';

interface EncounterFormProps {
  initialData?: Encounter;
  onSubmit: (data: EncounterFormData) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}

const riskLevels: { key: RiskLevel; label: string; color: string }[] = [
  { key: 'low', label: 'Low', color: '#166534' },
  { key: 'medium', label: 'Medium', color: '#92400e' },
  { key: 'high', label: 'High', color: '#c2410c' },
  { key: 'critical', label: 'Critical', color: '#dc2626' },
];

export const EncounterForm: React.FC<EncounterFormProps> = ({
  initialData,
  onSubmit,
  onCancel,
  isLoading = false,
}) => {
  const [anonymousId, setAnonymousId] = useState(initialData?.anonymous_id || '');
  const [riskLevel, setRiskLevel] = useState<RiskLevel | undefined>(initialData?.risk_level || undefined);
  const [locationNotes, setLocationNotes] = useState(initialData?.location_notes || '');
  const [latitude, setLatitude] = useState<number | null>(initialData?.latitude || null);
  const [longitude, setLongitude] = useState<number | null>(initialData?.longitude || null);
  const [observedConditions, setObservedConditions] = useState<string[]>(initialData?.observed_conditions || []);
  const [servicesRequested, setServicesRequested] = useState<string[]>(initialData?.services_requested || []);
  const [referralsGiven, setReferralsGiven] = useState<string[]>(initialData?.referrals_given || []);
  const [notes, setNotes] = useState(initialData?.notes || '');
  const [gettingLocation, setGettingLocation] = useState(false);

  useEffect(() => {
    if (!initialData && !anonymousId) {
      setAnonymousId(generateAnonymousId());
    }
  }, []);

  const handleGenerateNewId = () => {
    setAnonymousId(generateAnonymousId());
  };

  const handleGetLocation = async () => {
    setGettingLocation(true);
    try {
      // For web/mobile compatibility, we'll use a simple approach
      if (Platform.OS === 'web' && navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setLatitude(position.coords.latitude);
            setLongitude(position.coords.longitude);
            setGettingLocation(false);
          },
          (error) => {
            Alert.alert('Location Error', 'Unable to get your location. Please enter manually.');
            setGettingLocation(false);
          },
          { enableHighAccuracy: true, timeout: 10000 }
        );
      } else {
        // For native, we'd use expo-location, but for now show manual entry
        Alert.alert('Location', 'Please enter coordinates manually or enable location services.');
        setGettingLocation(false);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to get location');
      setGettingLocation(false);
    }
  };

  const toggleCondition = (condition: string) => {
    setObservedConditions(prev => 
      prev.includes(condition) 
        ? prev.filter(c => c !== condition)
        : [...prev, condition]
    );
  };

  const toggleService = (service: string) => {
    setServicesRequested(prev => 
      prev.includes(service) 
        ? prev.filter(s => s !== service)
        : [...prev, service]
    );
  };

  const toggleReferral = (referral: string) => {
    setReferralsGiven(prev => 
      prev.includes(referral) 
        ? prev.filter(r => r !== referral)
        : [...prev, referral]
    );
  };

  const handleSubmit = async () => {
    if (!anonymousId.trim()) {
      Alert.alert('Error', 'Anonymous ID is required');
      return;
    }

    const formData: EncounterFormData = {
      anonymous_id: anonymousId.trim(),
      risk_level: riskLevel,
      location_notes: locationNotes.trim() || undefined,
      latitude,
      longitude,
      observed_conditions: observedConditions.length > 0 ? observedConditions : undefined,
      services_requested: servicesRequested.length > 0 ? servicesRequested : undefined,
      referrals_given: referralsGiven.length > 0 ? referralsGiven : undefined,
      notes: notes.trim() || undefined,
    };

    await onSubmit(formData);
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Identification</Text>
        
        <View style={styles.idRow}>
          <View style={styles.idInputContainer}>
            <Text style={styles.label}>Anonymous ID</Text>
            <TextInput
              style={styles.input}
              value={anonymousId}
              onChangeText={setAnonymousId}
              placeholder="JO-XXXXXX"
              autoCapitalize="characters"
            />
          </View>
          <TouchableOpacity style={styles.generateBtn} onPress={handleGenerateNewId}>
            <Ionicons name="refresh" size={20} color="#2563eb" />
          </TouchableOpacity>
        </View>
        <Text style={styles.hint}>
          Use existing ID for returning individuals or generate new
        </Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Risk Assessment</Text>
        <View style={styles.riskContainer}>
          {riskLevels.map((level) => (
            <TouchableOpacity
              key={level.key}
              style={[
                styles.riskOption,
                riskLevel === level.key && { 
                  backgroundColor: `${level.color}15`,
                  borderColor: level.color,
                },
              ]}
              onPress={() => setRiskLevel(level.key)}
            >
              <View style={[
                styles.riskDot,
                { backgroundColor: level.color },
              ]} />
              <Text style={[
                styles.riskLabel,
                riskLevel === level.key && { color: level.color, fontWeight: '600' },
              ]}>
                {level.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Location</Text>
        
        <TouchableOpacity 
          style={styles.locationBtn} 
          onPress={handleGetLocation}
          disabled={gettingLocation}
        >
          {gettingLocation ? (
            <ActivityIndicator size="small" color="#2563eb" />
          ) : (
            <Ionicons name="locate" size={20} color="#2563eb" />
          )}
          <Text style={styles.locationBtnText}>
            {gettingLocation ? 'Getting location...' : 'Get Current Location'}
          </Text>
        </TouchableOpacity>

        {(latitude !== null && longitude !== null) && (
          <View style={styles.coordsDisplay}>
            <Ionicons name="location" size={16} color="#16a34a" />
            <Text style={styles.coordsText}>
              {latitude.toFixed(6)}, {longitude.toFixed(6)}
            </Text>
          </View>
        )}

        <Text style={styles.label}>Location Notes</Text>
        <TextInput
          style={[styles.input, styles.textArea]}
          value={locationNotes}
          onChangeText={setLocationNotes}
          placeholder="e.g., Under bridge near Main St, behind grocery store..."
          multiline
          numberOfLines={2}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Observations</Text>
        <MultiSelect
          label="Observed Conditions"
          options={OBSERVED_CONDITIONS}
          selected={observedConditions}
          onToggle={toggleCondition}
          maxHeight={180}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Services & Referrals</Text>
        <MultiSelect
          label="Services Requested"
          options={SERVICES_REQUESTED}
          selected={servicesRequested}
          onToggle={toggleService}
          maxHeight={150}
        />
        <MultiSelect
          label="Referrals Given"
          options={REFERRALS}
          selected={referralsGiven}
          onToggle={toggleReferral}
          maxHeight={150}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Additional Notes</Text>
        <TextInput
          style={[styles.input, styles.textArea, { minHeight: 100 }]}
          value={notes}
          onChangeText={setNotes}
          placeholder="Any additional observations or notes..."
          multiline
          numberOfLines={4}
          textAlignVertical="top"
        />
      </View>

      <View style={styles.buttonRow}>
        <TouchableOpacity style={styles.cancelBtn} onPress={onCancel}>
          <Text style={styles.cancelBtnText}>Cancel</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.submitBtn, isLoading && styles.submitBtnDisabled]} 
          onPress={handleSubmit}
          disabled={isLoading}
        >
          {isLoading ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <>
              <Ionicons name="checkmark" size={20} color="#ffffff" />
              <Text style={styles.submitBtnText}>
                {initialData ? 'Update Encounter' : 'Save Encounter'}
              </Text>
            </>
          )}
        </TouchableOpacity>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  section: {
    backgroundColor: '#ffffff',
    padding: 16,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 14,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#374151',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#f8fafc',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: '#1e293b',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  textArea: {
    minHeight: 60,
    textAlignVertical: 'top',
  },
  hint: {
    fontSize: 12,
    color: '#94a3b8',
    marginTop: 6,
  },
  idRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
  },
  idInputContainer: {
    flex: 1,
  },
  generateBtn: {
    backgroundColor: '#eff6ff',
    padding: 12,
    borderRadius: 10,
    marginBottom: 1,
  },
  riskContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  riskOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    backgroundColor: '#ffffff',
  },
  riskDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 8,
  },
  riskLabel: {
    fontSize: 14,
    color: '#64748b',
  },
  locationBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#eff6ff',
    paddingVertical: 12,
    borderRadius: 10,
    marginBottom: 12,
    gap: 8,
  },
  locationBtnText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2563eb',
  },
  coordsDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#dcfce7',
    padding: 10,
    borderRadius: 8,
    marginBottom: 12,
    gap: 6,
  },
  coordsText: {
    fontSize: 13,
    color: '#166534',
    fontFamily: 'monospace',
  },
  buttonRow: {
    flexDirection: 'row',
    padding: 16,
    gap: 12,
  },
  cancelBtn: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 10,
    backgroundColor: '#f1f5f9',
    alignItems: 'center',
  },
  cancelBtnText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#64748b',
  },
  submitBtn: {
    flex: 2,
    flexDirection: 'row',
    paddingVertical: 14,
    borderRadius: 10,
    backgroundColor: '#2563eb',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  submitBtnDisabled: {
    opacity: 0.7,
  },
  submitBtnText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#ffffff',
  },
});
