import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  SafeAreaView,
  ActivityIndicator,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, router } from 'expo-router';
import { StatCard } from '../components/StatCard';
import { EncounterCard } from '../components/EncounterCard';
import { EmptyState } from '../components/EmptyState';
import { getDashboardStats, fetchEncounters } from '../lib/encounterService';
import { DashboardStats, Encounter } from '../lib/types';
import { useAuth } from '../contexts/AuthContext';

export default function DashboardScreen() {
  const { worker, logout, isAuthenticated } = useAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentEncounters, setRecentEncounters] = useState<Encounter[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = async () => {
    try {
      const [statsData, encountersData] = await Promise.all([
        getDashboardStats(worker?.id),
        fetchEncounters(worker?.id),
      ]);
      setStats(statsData);
      setRecentEncounters(encountersData.slice(0, 5));
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      if (isAuthenticated) {
        loadData();
      }
    }, [isAuthenticated, worker?.id])
  );

  const onRefresh = () => {
    setRefreshing(true);
    loadData();
  };

  const handleLogout = () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign Out',
          style: 'destructive',
          onPress: async () => {
            try {
              await logout();
              router.replace('/login');
            } catch (error) {
              Alert.alert('Error', 'Failed to sign out');
            }
          },
        },
      ]
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#2563eb" />
          <Text style={styles.loadingText}>Loading dashboard...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#2563eb']} />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Journey On</Text>
            <Text style={styles.subtitle}>Outreach Tracker</Text>
          </View>
          <TouchableOpacity style={styles.profileBtn} onPress={handleLogout}>
            <View style={styles.avatarContainer}>
              <Text style={styles.avatarText}>
                {worker?.full_name?.charAt(0).toUpperCase() || 'W'}
              </Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* Worker Info */}
        {worker && (
          <View style={styles.workerBanner}>
            <View style={styles.workerInfo}>
              <Ionicons name="person-circle-outline" size={20} color="#2563eb" />
              <View>
                <Text style={styles.workerName}>{worker.full_name}</Text>
                <Text style={styles.workerRole}>
                  {worker.organization || worker.role.charAt(0).toUpperCase() + worker.role.slice(1)}
                </Text>
              </View>
            </View>
            <TouchableOpacity onPress={handleLogout}>
              <Ionicons name="log-out-outline" size={22} color="#64748b" />
            </TouchableOpacity>
          </View>
        )}

        {/* Privacy Notice */}
        <View style={styles.privacyBanner}>
          <Ionicons name="shield-checkmark" size={20} color="#059669" />
          <Text style={styles.privacyText}>
            Privacy-first: No personal identifiable information collected
          </Text>
        </View>

        {/* Stats Grid */}
        <View style={styles.statsSection}>
          <Text style={styles.sectionTitle}>Your Overview</Text>
          <View style={styles.statsRow}>
            <View style={styles.statHalf}>
              <StatCard
                title="Total Encounters"
                value={stats?.totalEncounters || 0}
                icon="clipboard-outline"
                color="#2563eb"
              />
            </View>
            <View style={styles.statHalf}>
              <StatCard
                title="Unique Individuals"
                value={stats?.uniqueIndividuals || 0}
                icon="people-outline"
                color="#7c3aed"
              />
            </View>
          </View>
          <View style={styles.statsRow}>
            <View style={styles.statHalf}>
              <StatCard
                title="High Risk"
                value={stats?.highRiskCount || 0}
                icon="alert-circle-outline"
                color="#dc2626"
              />
            </View>
            <View style={styles.statHalf}>
              <StatCard
                title="This Week"
                value={stats?.weekEncounters || 0}
                icon="calendar-outline"
                color="#059669"
              />
            </View>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionsRow}>
            <TouchableOpacity 
              style={styles.actionCard}
              onPress={() => router.push('/(tabs)/new')}
              activeOpacity={0.7}
            >
              <View style={[styles.actionIcon, { backgroundColor: '#eff6ff' }]}>
                <Ionicons name="add-circle" size={28} color="#2563eb" />
              </View>
              <Text style={styles.actionLabel}>New Encounter</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.actionCard}
              onPress={() => router.push('/(tabs)/search')}
              activeOpacity={0.7}
            >
              <View style={[styles.actionIcon, { backgroundColor: '#fef3c7' }]}>
                <Ionicons name="search" size={28} color="#d97706" />
              </View>
              <Text style={styles.actionLabel}>Find Individual</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.actionCard}
              onPress={() => router.push('/(tabs)/export')}
              activeOpacity={0.7}
            >
              <View style={[styles.actionIcon, { backgroundColor: '#dcfce7' }]}>
                <Ionicons name="download" size={28} color="#059669" />
              </View>
              <Text style={styles.actionLabel}>Export Data</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Recent Encounters */}
        <View style={styles.recentSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Your Recent Encounters</Text>
            <TouchableOpacity onPress={() => router.push('/(tabs)/encounters')}>
              <Text style={styles.viewAll}>View All</Text>
            </TouchableOpacity>
          </View>
          
          {recentEncounters.length === 0 ? (
            <EmptyState
              icon="clipboard-outline"
              title="No encounters yet"
              description="Start recording encounters to see them here"
              actionLabel="Record First Encounter"
              onAction={() => router.push('/(tabs)/new')}
            />
          ) : (
            recentEncounters.map((encounter) => (
              <EncounterCard
                key={encounter.id}
                encounter={encounter}
                onPress={() => router.push({
                  pathname: '/(tabs)/encounters',
                  params: { selectedId: encounter.id }
                })}
              />
            ))
          )}
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  scrollView: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    fontSize: 15,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 12,
  },
  greeting: {
    fontSize: 28,
    fontWeight: '800',
    color: '#1e293b',
  },
  subtitle: {
    fontSize: 15,
    color: '#64748b',
    marginTop: 2,
  },
  profileBtn: {
    padding: 4,
  },
  avatarContainer: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#2563eb',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 18,
    fontWeight: '700',
    color: '#ffffff',
  },
  workerBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#ffffff',
    marginHorizontal: 16,
    padding: 12,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  workerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  workerName: {
    fontSize: 15,
    fontWeight: '600',
    color: '#1e293b',
  },
  workerRole: {
    fontSize: 12,
    color: '#64748b',
  },
  privacyBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#dcfce7',
    marginHorizontal: 16,
    padding: 12,
    borderRadius: 10,
    gap: 10,
    marginBottom: 20,
  },
  privacyText: {
    flex: 1,
    fontSize: 13,
    color: '#166534',
    fontWeight: '500',
  },
  statsSection: {
    paddingHorizontal: 16,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 14,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
  },
  statHalf: {
    flex: 1,
  },
  quickActions: {
    paddingHorizontal: 16,
    marginBottom: 20,
  },
  actionsRow: {
    flexDirection: 'row',
    gap: 12,
  },
  actionCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  actionIcon: {
    width: 52,
    height: 52,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  actionLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#475569',
    textAlign: 'center',
  },
  recentSection: {
    paddingHorizontal: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  viewAll: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2563eb',
  },
});
