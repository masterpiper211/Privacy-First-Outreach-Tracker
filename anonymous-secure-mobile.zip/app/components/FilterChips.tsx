import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { RiskLevel } from '../lib/types';

interface FilterChipsProps {
  selectedFilter: RiskLevel | 'all';
  onFilterChange: (filter: RiskLevel | 'all') => void;
}

const filters: { key: RiskLevel | 'all'; label: string; color: string }[] = [
  { key: 'all', label: 'All', color: '#2563eb' },
  { key: 'critical', label: 'Critical', color: '#dc2626' },
  { key: 'high', label: 'High', color: '#c2410c' },
  { key: 'medium', label: 'Medium', color: '#92400e' },
  { key: 'low', label: 'Low', color: '#166534' },
];

export const FilterChips: React.FC<FilterChipsProps> = ({ selectedFilter, onFilterChange }) => {
  return (
    <ScrollView 
      horizontal 
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.container}
    >
      {filters.map((filter) => {
        const isSelected = selectedFilter === filter.key;
        return (
          <TouchableOpacity
            key={filter.key}
            style={[
              styles.chip,
              isSelected && { backgroundColor: filter.color },
            ]}
            onPress={() => onFilterChange(filter.key)}
            activeOpacity={0.7}
          >
            <Text
              style={[
                styles.chipText,
                isSelected && styles.chipTextSelected,
              ]}
            >
              {filter.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  chip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    marginRight: 8,
  },
  chipText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#64748b',
  },
  chipTextSelected: {
    color: '#ffffff',
  },
});
