import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
  Platform,
  Share,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { fetchEncounters, exportToCSV, getDashboardStats } from '../lib/encounterService';
import { Encounter, DashboardStats, RiskLevel } from '../lib/types';
import { useAuth } from '../contexts/AuthContext';

export default function ExportScreen() {
  const { worker } = useAuth();
  const [encounters, setEncounters] = useState<Encounter[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [dateRange, setDateRange] = useState<'all' | 'week' | 'month'>('all');
  const [riskFilter, setRiskFilter] = useState<RiskLevel | 'all'>('all');

  useEffect(() => {
    loadData();
  }, [worker?.id]);

  const loadData = async () => {
    try {
      const [encountersData, statsData] = await Promise.all([
        fetchEncounters(worker?.id),
        getDashboardStats(worker?.id),
      ]);
      setEncounters(encountersData);
      setStats(statsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getFilteredEncounters = () => {
    let filtered = [...encounters];

    // Date filter
    const now = new Date();
    if (dateRange === 'week') {
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      filtered = filtered.filter(e => new Date(e.encounter_date) >= weekAgo);
    } else if (dateRange === 'month') {
      const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      filtered = filtered.filter(e => new Date(e.encounter_date) >= monthAgo);
    }

    // Risk filter
    if (riskFilter !== 'all') {
      filtered = filtered.filter(e => e.risk_level === riskFilter);
    }

    return filtered;
  };

  const handleExport = async () => {
    const filteredData = getFilteredEncounters();
    
    if (filteredData.length === 0) {
      Alert.alert('No Data', 'No encounters match the selected filters.');
      return;
    }

    setExporting(true);
    try {
      const csvContent = exportToCSV(filteredData);
      
      if (Platform.OS === 'web') {
        // Web: Download file
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `outreach-encounters-${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        Alert.alert('Success', `Exported ${filteredData.length} encounters to CSV`);
      } else {
        // Mobile: Share
        await Share.share({
          message: csvContent,
          title: 'Outreach Encounters Export',
        });
      }
    } catch (error) {
      console.error('Export error:', error);
      Alert.alert('Error', 'Failed to export data');
    } finally {
      setExporting(false);
    }
  };

  const filteredCount = getFilteredEncounters().length;

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#2563eb" />
          <Text style={styles.loadingText}>Loading data...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Export Data</Text>
          <Text style={styles.subtitle}>Download your encounter data as CSV</Text>
        </View>

        {/* Summary Card */}
        <View style={styles.summaryCard}>
          <View style={styles.summaryHeader}>
            <Ionicons name="analytics-outline" size={24} color="#2563eb" />
            <Text style={styles.summaryTitle}>Your Data Summary</Text>
          </View>
          <View style={styles.summaryGrid}>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{stats?.totalEncounters || 0}</Text>
              <Text style={styles.summaryLabel}>Total Records</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{stats?.uniqueIndividuals || 0}</Text>
              <Text style={styles.summaryLabel}>Individuals</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{stats?.weekEncounters || 0}</Text>
              <Text style={styles.summaryLabel}>This Week</Text>
            </View>
          </View>
        </View>

        {/* Filters */}
        <View style={styles.filtersSection}>
          <Text style={styles.sectionTitle}>Export Filters</Text>
          
          {/* Date Range */}
          <View style={styles.filterGroup}>
            <Text style={styles.filterLabel}>Date Range</Text>
            <View style={styles.filterOptions}>
              {[
                { key: 'all', label: 'All Time' },
                { key: 'month', label: 'Last 30 Days' },
                { key: 'week', label: 'Last 7 Days' },
              ].map((option) => (
                <TouchableOpacity
                  key={option.key}
                  style={[
                    styles.filterOption,
                    dateRange === option.key && styles.filterOptionActive,
                  ]}
                  onPress={() => setDateRange(option.key as typeof dateRange)}
                >
                  <Text
                    style={[
                      styles.filterOptionText,
                      dateRange === option.key && styles.filterOptionTextActive,
                    ]}
                  >
                    {option.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Risk Level */}
          <View style={styles.filterGroup}>
            <Text style={styles.filterLabel}>Risk Level</Text>
            <View style={styles.filterOptions}>
              {[
                { key: 'all', label: 'All', color: '#2563eb' },
                { key: 'critical', label: 'Critical', color: '#dc2626' },
                { key: 'high', label: 'High', color: '#c2410c' },
                { key: 'medium', label: 'Medium', color: '#92400e' },
                { key: 'low', label: 'Low', color: '#166534' },
              ].map((option) => (
                <TouchableOpacity
                  key={option.key}
                  style={[
                    styles.filterOption,
                    riskFilter === option.key && { backgroundColor: option.color },
                  ]}
                  onPress={() => setRiskFilter(option.key as typeof riskFilter)}
                >
                  <Text
                    style={[
                      styles.filterOptionText,
                      riskFilter === option.key && styles.filterOptionTextActive,
                    ]}
                  >
                    {option.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>

        {/* Export Preview */}
        <View style={styles.previewCard}>
          <View style={styles.previewHeader}>
            <Ionicons name="document-text-outline" size={20} color="#64748b" />
            <Text style={styles.previewTitle}>Export Preview</Text>
          </View>
          <View style={styles.previewContent}>
            <View style={styles.previewRow}>
              <Text style={styles.previewLabel}>Records to export:</Text>
              <Text style={styles.previewValue}>{filteredCount}</Text>
            </View>
            <View style={styles.previewRow}>
              <Text style={styles.previewLabel}>Format:</Text>
              <Text style={styles.previewValue}>CSV (Comma Separated)</Text>
            </View>
            <View style={styles.previewRow}>
              <Text style={styles.previewLabel}>Includes:</Text>
              <Text style={styles.previewValue}>All encounter fields</Text>
            </View>
          </View>
        </View>

        {/* Privacy Notice */}
        <View style={styles.privacyNotice}>
          <Ionicons name="shield-checkmark" size={20} color="#059669" />
          <Text style={styles.privacyText}>
            Exported data contains only anonymous IDs. No personally identifiable information is included.
          </Text>
        </View>

        {/* Export Button */}
        <TouchableOpacity
          style={[styles.exportBtn, (exporting || filteredCount === 0) && styles.exportBtnDisabled]}
          onPress={handleExport}
          disabled={exporting || filteredCount === 0}
        >
          {exporting ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <>
              <Ionicons name="download-outline" size={22} color="#ffffff" />
              <Text style={styles.exportBtnText}>
                Export {filteredCount} Records
              </Text>
            </>
          )}
        </TouchableOpacity>

        {/* CSV Fields Info */}
        <View style={styles.fieldsInfo}>
          <Text style={styles.fieldsTitle}>CSV Fields Included:</Text>
          <View style={styles.fieldsList}>
            {[
              'Anonymous ID',
              'Date & Time',
              'GPS Coordinates',
              'Location Notes',
              'Risk Level',
              'Observed Conditions',
              'Services Requested',
              'Referrals Given',
              'Notes',
            ].map((field, index) => (
              <View key={index} style={styles.fieldItem}>
                <Ionicons name="checkmark-circle" size={14} color="#059669" />
                <Text style={styles.fieldText}>{field}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  scrollView: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    fontSize: 15,
    color: '#64748b',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#1e293b',
  },
  subtitle: {
    fontSize: 15,
    color: '#64748b',
    marginTop: 4,
  },
  summaryCard: {
    backgroundColor: '#ffffff',
    marginHorizontal: 16,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  summaryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 16,
  },
  summaryTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
  },
  summaryGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  summaryItem: {
    flex: 1,
    backgroundColor: '#f8fafc',
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
  },
  summaryValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#2563eb',
  },
  summaryLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
  },
  filtersSection: {
    backgroundColor: '#ffffff',
    marginHorizontal: 16,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 16,
  },
  filterGroup: {
    marginBottom: 16,
  },
  filterLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#64748b',
    marginBottom: 10,
  },
  filterOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  filterOption: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
  },
  filterOptionActive: {
    backgroundColor: '#2563eb',
  },
  filterOptionText: {
    fontSize: 13,
    fontWeight: '500',
    color: '#64748b',
  },
  filterOptionTextActive: {
    color: '#ffffff',
  },
  previewCard: {
    backgroundColor: '#ffffff',
    marginHorizontal: 16,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  previewHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  previewTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
  },
  previewContent: {
    gap: 8,
  },
  previewRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  previewLabel: {
    fontSize: 14,
    color: '#64748b',
  },
  previewValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1e293b',
  },
  privacyNotice: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#dcfce7',
    marginHorizontal: 16,
    padding: 12,
    borderRadius: 10,
    gap: 10,
    marginBottom: 20,
  },
  privacyText: {
    flex: 1,
    fontSize: 13,
    color: '#166534',
    lineHeight: 18,
  },
  exportBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#2563eb',
    marginHorizontal: 16,
    paddingVertical: 16,
    borderRadius: 12,
    gap: 10,
  },
  exportBtnDisabled: {
    opacity: 0.5,
  },
  exportBtnText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#ffffff',
  },
  fieldsInfo: {
    marginHorizontal: 16,
    marginTop: 24,
  },
  fieldsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
    marginBottom: 12,
  },
  fieldsList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  fieldItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#f8fafc',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 6,
  },
  fieldText: {
    fontSize: 12,
    color: '#475569',
  },
});
