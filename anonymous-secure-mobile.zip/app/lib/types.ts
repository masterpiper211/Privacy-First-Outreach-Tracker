// Type definitions for Journey On Outreach Tracker

export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';
export type WorkerRole = 'worker' | 'supervisor' | 'admin';

export interface Worker {
  id: string;
  auth_user_id: string | null;
  email: string;
  full_name: string;
  role: WorkerRole;
  phone: string | null;
  organization: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Encounter {
  id: string;
  anonymous_id: string;
  encounter_date: string;
  latitude: number | null;
  longitude: number | null;
  location_notes: string | null;
  risk_level: RiskLevel | null;
  observed_conditions: string[] | null;
  services_requested: string[] | null;
  referrals_given: string[] | null;
  notes: string | null;
  worker_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface EncounterFormData {
  anonymous_id: string;
  latitude?: number | null;
  longitude?: number | null;
  location_notes?: string;
  risk_level?: RiskLevel;
  observed_conditions?: string[];
  services_requested?: string[];
  referrals_given?: string[];
  notes?: string;
  worker_id?: string;
}

export interface DashboardStats {
  totalEncounters: number;
  uniqueIndividuals: number;
  highRiskCount: number;
  todayEncounters: number;
  weekEncounters: number;
}

export interface AuthState {
  isAuthenticated: boolean;
  isLoading: boolean;
  user: any | null;
  worker: Worker | null;
}

export const OBSERVED_CONDITIONS = [
  'Appears intoxicated',
  'Signs of mental distress',
  'Physical injury visible',
  'Malnourished',
  'Inadequate clothing',
  'Sleeping rough',
  'With belongings',
  'With pet',
  'In group',
  'Alone',
  'Verbal communication',
  'Non-verbal',
  'Cooperative',
  'Uncooperative',
  'Disoriented',
];

export const SERVICES_REQUESTED = [
  'Food/Water',
  'Shelter',
  'Medical attention',
  'Mental health support',
  'Substance abuse help',
  'Clothing',
  'Hygiene supplies',
  'Transportation',
  'Legal assistance',
  'Employment help',
  'ID/Documentation',
  'Phone/Communication',
  'Family reconnection',
  'None requested',
];

export const REFERRALS = [
  'Emergency shelter',
  'Food bank',
  'Hospital/ER',
  'Mental health clinic',
  'Substance abuse program',
  'Social services',
  'Legal aid',
  'Job training program',
  'Housing assistance',
  'Veterans services',
  'Youth services',
  'Domestic violence shelter',
  'Drop-in center',
  'Mobile health unit',
];
