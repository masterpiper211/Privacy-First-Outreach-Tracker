import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TextInput,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  Modal,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { EncounterCard } from '../components/EncounterCard';
import { EncounterDetail } from '../components/EncounterDetail';
import { EmptyState } from '../components/EmptyState';
import { fetchEncountersByAnonymousId, deleteEncounter } from '../lib/encounterService';
import { Encounter } from '../lib/types';

export default function SearchScreen() {
  const [searchId, setSearchId] = useState('');
  const [encounters, setEncounters] = useState<Encounter[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [selectedEncounter, setSelectedEncounter] = useState<Encounter | null>(null);
  const [showDetail, setShowDetail] = useState(false);

  const handleSearch = async () => {
    if (!searchId.trim()) {
      Alert.alert('Error', 'Please enter an anonymous ID to search');
      return;
    }

    setLoading(true);
    setHasSearched(true);
    try {
      // Search across all encounters (not filtered by worker) to find individual history
      const results = await fetchEncountersByAnonymousId(searchId.trim().toUpperCase());
      setEncounters(results);
    } catch (error) {
      console.error('Error searching:', error);
      Alert.alert('Error', 'Failed to search encounters');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = (encounter: Encounter) => {
    Alert.alert(
      'Delete Encounter',
      'Are you sure you want to delete this encounter?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteEncounter(encounter.id);
              setEncounters(prev => prev.filter(e => e.id !== encounter.id));
              setShowDetail(false);
              setSelectedEncounter(null);
            } catch (error) {
              Alert.alert('Error', 'Failed to delete encounter');
            }
          },
        },
      ]
    );
  };

  const getTotalStats = () => {
    if (encounters.length === 0) return null;
    
    const services = new Set<string>();
    const referrals = new Set<string>();
    const conditions = new Set<string>();
    
    encounters.forEach(e => {
      e.services_requested?.forEach(s => services.add(s));
      e.referrals_given?.forEach(r => referrals.add(r));
      e.observed_conditions?.forEach(c => conditions.add(c));
    });

    return {
      totalEncounters: encounters.length,
      uniqueServices: services.size,
      uniqueReferrals: referrals.size,
      uniqueConditions: conditions.size,
    };
  };

  const stats = getTotalStats();

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Find Individual</Text>
        <Text style={styles.subtitle}>Search encounter history by anonymous ID</Text>
      </View>

      {/* Search Input */}
      <View style={styles.searchSection}>
        <View style={styles.searchInputContainer}>
          <Ionicons name="finger-print-outline" size={22} color="#64748b" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            value={searchId}
            onChangeText={setSearchId}
            placeholder="Enter Anonymous ID (e.g., JO-ABC123)"
            placeholderTextColor="#94a3b8"
            autoCapitalize="characters"
            autoCorrect={false}
            onSubmitEditing={handleSearch}
          />
          {searchId.length > 0 && (
            <TouchableOpacity onPress={() => setSearchId('')} style={styles.clearBtn}>
              <Ionicons name="close-circle" size={20} color="#94a3b8" />
            </TouchableOpacity>
          )}
        </View>
        <TouchableOpacity 
          style={[styles.searchBtn, loading && styles.searchBtnDisabled]} 
          onPress={handleSearch}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <Ionicons name="search" size={22} color="#ffffff" />
          )}
        </TouchableOpacity>
      </View>

      {/* Info Banner */}
      <View style={styles.infoBanner}>
        <Ionicons name="information-circle-outline" size={18} color="#2563eb" />
        <Text style={styles.infoText}>
          Search shows all encounters for an individual across all workers
        </Text>
      </View>

      {/* Results */}
      {!hasSearched ? (
        <View style={styles.initialState}>
          <View style={styles.initialIcon}>
            <Ionicons name="search" size={48} color="#cbd5e1" />
          </View>
          <Text style={styles.initialTitle}>Search for an Individual</Text>
          <Text style={styles.initialText}>
            Enter an anonymous ID to view all encounters and history for that individual
          </Text>
        </View>
      ) : loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#2563eb" />
          <Text style={styles.loadingText}>Searching...</Text>
        </View>
      ) : encounters.length === 0 ? (
        <EmptyState
          icon="person-outline"
          title="No encounters found"
          description={`No records found for ID "${searchId}". Check the ID and try again.`}
        />
      ) : (
        <>
          {/* Stats Summary */}
          {stats && (
            <View style={styles.statsSummary}>
              <View style={styles.summaryHeader}>
                <Ionicons name="finger-print" size={24} color="#2563eb" />
                <Text style={styles.summaryId}>{searchId.toUpperCase()}</Text>
              </View>
              <View style={styles.statsGrid}>
                <View style={styles.statBox}>
                  <Text style={styles.statValue}>{stats.totalEncounters}</Text>
                  <Text style={styles.statLabel}>Encounters</Text>
                </View>
                <View style={styles.statBox}>
                  <Text style={styles.statValue}>{stats.uniqueServices}</Text>
                  <Text style={styles.statLabel}>Services</Text>
                </View>
                <View style={styles.statBox}>
                  <Text style={styles.statValue}>{stats.uniqueReferrals}</Text>
                  <Text style={styles.statLabel}>Referrals</Text>
                </View>
              </View>
            </View>
          )}

          {/* Encounters List */}
          <FlatList
            data={encounters}
            renderItem={({ item }) => (
              <EncounterCard
                encounter={item}
                onPress={() => {
                  setSelectedEncounter(item);
                  setShowDetail(true);
                }}
                onDelete={() => handleDelete(item)}
              />
            )}
            keyExtractor={item => item.id}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            ListHeaderComponent={
              <Text style={styles.listHeader}>Encounter History</Text>
            }
          />
        </>
      )}

      {/* Detail Modal */}
      <Modal
        visible={showDetail}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => {
          setShowDetail(false);
          setSelectedEncounter(null);
        }}
      >
        {selectedEncounter && (
          <EncounterDetail
            encounter={selectedEncounter}
            onEdit={() => {}}
            onDelete={() => handleDelete(selectedEncounter)}
            onClose={() => {
              setShowDetail(false);
              setSelectedEncounter(null);
            }}
          />
        )}
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#1e293b',
  },
  subtitle: {
    fontSize: 15,
    color: '#64748b',
    marginTop: 4,
  },
  searchSection: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 10,
    marginBottom: 12,
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 52,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  searchIcon: {
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#1e293b',
    fontFamily: 'monospace',
  },
  clearBtn: {
    padding: 4,
  },
  searchBtn: {
    width: 52,
    height: 52,
    borderRadius: 12,
    backgroundColor: '#2563eb',
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchBtnDisabled: {
    opacity: 0.7,
  },
  infoBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#eff6ff',
    marginHorizontal: 16,
    padding: 10,
    borderRadius: 8,
    gap: 8,
    marginBottom: 16,
  },
  infoText: {
    flex: 1,
    fontSize: 12,
    color: '#1e40af',
  },
  initialState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  initialIcon: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  initialTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 8,
  },
  initialText: {
    fontSize: 15,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 22,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    fontSize: 15,
    color: '#64748b',
  },
  statsSummary: {
    backgroundColor: '#ffffff',
    marginHorizontal: 16,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  summaryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  summaryId: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1e293b',
    fontFamily: 'monospace',
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  statBox: {
    flex: 1,
    backgroundColor: '#f8fafc',
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#2563eb',
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
  },
  listContent: {
    padding: 16,
    paddingTop: 0,
  },
  listHeader: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
  },
});
