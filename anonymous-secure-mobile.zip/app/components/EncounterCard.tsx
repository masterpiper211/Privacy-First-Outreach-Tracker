import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Encounter } from '../lib/types';
import { RiskBadge } from './RiskBadge';

interface EncounterCardProps {
  encounter: Encounter;
  onPress: () => void;
  onDelete?: () => void;
}

export const EncounterCard: React.FC<EncounterCardProps> = ({ encounter, onPress, onDelete }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const hasLocation = encounter.latitude && encounter.longitude;
  const conditionsCount = encounter.observed_conditions?.length || 0;
  const servicesCount = encounter.services_requested?.length || 0;
  const referralsCount = encounter.referrals_given?.length || 0;

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.header}>
        <View style={styles.idContainer}>
          <Ionicons name="finger-print-outline" size={18} color="#2563eb" />
          <Text style={styles.anonymousId}>{encounter.anonymous_id}</Text>
        </View>
        <RiskBadge level={encounter.risk_level} size="small" />
      </View>

      <View style={styles.dateRow}>
        <Ionicons name="calendar-outline" size={14} color="#64748b" />
        <Text style={styles.date}>{formatDate(encounter.encounter_date)}</Text>
      </View>

      {hasLocation && (
        <View style={styles.locationRow}>
          <Ionicons name="location-outline" size={14} color="#64748b" />
          <Text style={styles.locationText} numberOfLines={1}>
            {encounter.location_notes || `${encounter.latitude?.toFixed(4)}, ${encounter.longitude?.toFixed(4)}`}
          </Text>
        </View>
      )}

      {encounter.notes && (
        <Text style={styles.notes} numberOfLines={2}>
          {encounter.notes}
        </Text>
      )}

      <View style={styles.footer}>
        <View style={styles.stats}>
          {conditionsCount > 0 && (
            <View style={styles.statItem}>
              <Ionicons name="eye-outline" size={12} color="#64748b" />
              <Text style={styles.statText}>{conditionsCount}</Text>
            </View>
          )}
          {servicesCount > 0 && (
            <View style={styles.statItem}>
              <Ionicons name="hand-left-outline" size={12} color="#64748b" />
              <Text style={styles.statText}>{servicesCount}</Text>
            </View>
          )}
          {referralsCount > 0 && (
            <View style={styles.statItem}>
              <Ionicons name="arrow-forward-outline" size={12} color="#64748b" />
              <Text style={styles.statText}>{referralsCount}</Text>
            </View>
          )}
        </View>

        {onDelete && (
          <TouchableOpacity 
            style={styles.deleteBtn} 
            onPress={() => onDelete()}
          >
            <Ionicons name="trash-outline" size={16} color="#ef4444" />
          </TouchableOpacity>
        )}
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  idContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  anonymousId: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    fontFamily: 'monospace',
  },
  dateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  date: {
    fontSize: 13,
    color: '#64748b',
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 8,
  },
  locationText: {
    fontSize: 13,
    color: '#64748b',
    flex: 1,
  },
  notes: {
    fontSize: 14,
    color: '#475569',
    lineHeight: 20,
    marginTop: 4,
    marginBottom: 8,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  stats: {
    flexDirection: 'row',
    gap: 12,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statText: {
    fontSize: 12,
    color: '#64748b',
  },
  deleteBtn: {
    padding: 6,
  },
});
