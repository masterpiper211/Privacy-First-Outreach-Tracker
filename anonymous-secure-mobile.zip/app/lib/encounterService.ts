// Service layer for encounter operations
import { supabase } from './supabase';
import { Encounter, EncounterFormData, DashboardStats } from './types';

// Generate anonymous ID (format: JO-XXXXXX)
export const generateAnonymousId = (): string => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let result = 'JO-';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

// Fetch all encounters (optionally filtered by worker)
export const fetchEncounters = async (workerId?: string): Promise<Encounter[]> => {
  let query = supabase
    .from('encounters')
    .select('*')
    .order('encounter_date', { ascending: false });

  if (workerId) {
    query = query.eq('worker_id', workerId);
  }

  const { data, error } = await query;

  if (error) {
    console.error('Error fetching encounters:', error);
    throw error;
  }

  return data || [];
};

// Fetch encounters by anonymous ID
export const fetchEncountersByAnonymousId = async (anonymousId: string): Promise<Encounter[]> => {
  const { data, error } = await supabase
    .from('encounters')
    .select('*')
    .eq('anonymous_id', anonymousId)
    .order('encounter_date', { ascending: false });

  if (error) {
    console.error('Error fetching encounters by ID:', error);
    throw error;
  }

  return data || [];
};

// Create new encounter
export const createEncounter = async (formData: EncounterFormData): Promise<Encounter> => {
  const { data, error } = await supabase
    .from('encounters')
    .insert([{
      anonymous_id: formData.anonymous_id,
      latitude: formData.latitude,
      longitude: formData.longitude,
      location_notes: formData.location_notes,
      risk_level: formData.risk_level,
      observed_conditions: formData.observed_conditions,
      services_requested: formData.services_requested,
      referrals_given: formData.referrals_given,
      notes: formData.notes,
      worker_id: formData.worker_id,
    }])
    .select()
    .single();

  if (error) {
    console.error('Error creating encounter:', error);
    throw error;
  }

  return data;
};

// Update encounter
export const updateEncounter = async (id: string, formData: Partial<EncounterFormData>): Promise<Encounter> => {
  const { data, error } = await supabase
    .from('encounters')
    .update({
      ...formData,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('Error updating encounter:', error);
    throw error;
  }

  return data;
};

// Delete encounter
export const deleteEncounter = async (id: string): Promise<void> => {
  const { error } = await supabase
    .from('encounters')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Error deleting encounter:', error);
    throw error;
  }
};

// Get dashboard statistics (optionally filtered by worker)
export const getDashboardStats = async (workerId?: string): Promise<DashboardStats> => {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
  const weekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();

  // Get all encounters
  let query = supabase
    .from('encounters')
    .select('anonymous_id, risk_level, encounter_date, worker_id');

  if (workerId) {
    query = query.eq('worker_id', workerId);
  }

  const { data: allEncounters, error: allError } = await query;

  if (allError) {
    console.error('Error fetching stats:', allError);
    throw allError;
  }

  const encounters = allEncounters || [];
  const uniqueIds = new Set(encounters.map(e => e.anonymous_id));
  const highRisk = encounters.filter(e => e.risk_level === 'high' || e.risk_level === 'critical').length;
  const todayCount = encounters.filter(e => e.encounter_date >= todayStart).length;
  const weekCount = encounters.filter(e => e.encounter_date >= weekStart).length;

  return {
    totalEncounters: encounters.length,
    uniqueIndividuals: uniqueIds.size,
    highRiskCount: highRisk,
    todayEncounters: todayCount,
    weekEncounters: weekCount,
  };
};

// Export encounters to CSV format
export const exportToCSV = (encounters: Encounter[]): string => {
  const headers = [
    'Anonymous ID',
    'Date',
    'Latitude',
    'Longitude',
    'Location Notes',
    'Risk Level',
    'Observed Conditions',
    'Services Requested',
    'Referrals Given',
    'Notes',
  ];

  const rows = encounters.map(e => [
    e.anonymous_id,
    new Date(e.encounter_date).toLocaleString(),
    e.latitude?.toString() || '',
    e.longitude?.toString() || '',
    `"${(e.location_notes || '').replace(/"/g, '""')}"`,
    e.risk_level || '',
    `"${(e.observed_conditions || []).join(', ')}"`,
    `"${(e.services_requested || []).join(', ')}"`,
    `"${(e.referrals_given || []).join(', ')}"`,
    `"${(e.notes || '').replace(/"/g, '""')}"`,
  ]);

  return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
};
