import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { RiskLevel } from '../lib/types';

interface RiskBadgeProps {
  level: RiskLevel | null;
  size?: 'small' | 'medium' | 'large';
}

const riskColors: Record<RiskLevel, { bg: string; text: string }> = {
  low: { bg: '#dcfce7', text: '#166534' },
  medium: { bg: '#fef3c7', text: '#92400e' },
  high: { bg: '#fed7aa', text: '#c2410c' },
  critical: { bg: '#fecaca', text: '#dc2626' },
};

export const RiskBadge: React.FC<RiskBadgeProps> = ({ level, size = 'medium' }) => {
  if (!level) {
    return (
      <View style={[styles.badge, styles.unknown, styles[size]]}>
        <Text style={[styles.text, styles.unknownText, styles[`${size}Text`]]}>Unknown</Text>
      </View>
    );
  }

  const colors = riskColors[level];

  return (
    <View style={[styles.badge, { backgroundColor: colors.bg }, styles[size]]}>
      <Text style={[styles.text, { color: colors.text }, styles[`${size}Text`]]}>
        {level.charAt(0).toUpperCase() + level.slice(1)}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  badge: {
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  unknown: {
    backgroundColor: '#f1f5f9',
  },
  unknownText: {
    color: '#64748b',
  },
  text: {
    fontWeight: '600',
  },
  small: {
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  smallText: {
    fontSize: 10,
  },
  medium: {
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  mediumText: {
    fontSize: 12,
  },
  large: {
    paddingHorizontal: 16,
    paddingVertical: 6,
  },
  largeText: {
    fontSize: 14,
  },
});
