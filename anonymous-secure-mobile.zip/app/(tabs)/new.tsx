import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Alert,
} from 'react-native';
import { router } from 'expo-router';
import { EncounterForm } from '../components/EncounterForm';
import { createEncounter } from '../lib/encounterService';
import { EncounterFormData } from '../lib/types';
import { useAuth } from '../contexts/AuthContext';

export default function NewEncounterScreen() {
  const { worker } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (formData: EncounterFormData) => {
    setIsSubmitting(true);
    try {
      // Associate encounter with current worker
      const encounterData: EncounterFormData = {
        ...formData,
        worker_id: worker?.id,
      };
      
      await createEncounter(encounterData);
      Alert.alert(
        'Success',
        `Encounter recorded for ${formData.anonymous_id}`,
        [
          {
            text: 'View Encounters',
            onPress: () => router.push('/(tabs)/encounters'),
          },
          {
            text: 'Record Another',
            style: 'cancel',
          },
        ]
      );
    } catch (error) {
      console.error('Error creating encounter:', error);
      Alert.alert('Error', 'Failed to save encounter. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    Alert.alert(
      'Discard Changes?',
      'Are you sure you want to discard this encounter?',
      [
        { text: 'Keep Editing', style: 'cancel' },
        {
          text: 'Discard',
          style: 'destructive',
          onPress: () => router.push('/(tabs)'),
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>New Encounter</Text>
        <Text style={styles.subtitle}>
          Recording as {worker?.full_name || 'Worker'}
        </Text>
      </View>
      
      <EncounterForm
        onSubmit={handleSubmit}
        onCancel={handleCancel}
        isLoading={isSubmitting}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#1e293b',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
  },
});
