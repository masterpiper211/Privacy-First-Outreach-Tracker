import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  SafeAreaView,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Modal,
} from 'react-native';
import { useFocusEffect, useLocalSearchParams, router } from 'expo-router';
import { EncounterCard } from '../components/EncounterCard';
import { FilterChips } from '../components/FilterChips';
import { SearchBar } from '../components/SearchBar';
import { EmptyState } from '../components/EmptyState';
import { EncounterDetail } from '../components/EncounterDetail';
import { EncounterForm } from '../components/EncounterForm';
import { fetchEncounters, deleteEncounter, updateEncounter } from '../lib/encounterService';
import { Encounter, RiskLevel, EncounterFormData } from '../lib/types';
import { useAuth } from '../contexts/AuthContext';

export default function EncountersScreen() {
  const { worker } = useAuth();
  const params = useLocalSearchParams<{ selectedId?: string }>();
  const [encounters, setEncounters] = useState<Encounter[]>([]);
  const [filteredEncounters, setFilteredEncounters] = useState<Encounter[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [riskFilter, setRiskFilter] = useState<RiskLevel | 'all'>('all');
  const [selectedEncounter, setSelectedEncounter] = useState<Encounter | null>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);

  const loadEncounters = async () => {
    try {
      const data = await fetchEncounters(worker?.id);
      setEncounters(data);
    } catch (error) {
      console.error('Error loading encounters:', error);
      Alert.alert('Error', 'Failed to load encounters');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      loadEncounters();
    }, [worker?.id])
  );

  // Handle deep link to specific encounter
  useEffect(() => {
    if (params.selectedId && encounters.length > 0) {
      const encounter = encounters.find(e => e.id === params.selectedId);
      if (encounter) {
        setSelectedEncounter(encounter);
        setShowDetail(true);
      }
    }
  }, [params.selectedId, encounters]);

  // Filter encounters based on search and risk level
  useEffect(() => {
    let filtered = [...encounters];

    // Apply risk filter
    if (riskFilter !== 'all') {
      filtered = filtered.filter(e => e.risk_level === riskFilter);
    }

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(e =>
        e.anonymous_id.toLowerCase().includes(query) ||
        e.notes?.toLowerCase().includes(query) ||
        e.location_notes?.toLowerCase().includes(query)
      );
    }

    setFilteredEncounters(filtered);
  }, [encounters, riskFilter, searchQuery]);

  const onRefresh = () => {
    setRefreshing(true);
    loadEncounters();
  };

  const handleDelete = (encounter: Encounter) => {
    Alert.alert(
      'Delete Encounter',
      `Are you sure you want to delete this encounter for ${encounter.anonymous_id}? This action cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteEncounter(encounter.id);
              setEncounters(prev => prev.filter(e => e.id !== encounter.id));
              setShowDetail(false);
              setSelectedEncounter(null);
            } catch (error) {
              Alert.alert('Error', 'Failed to delete encounter');
            }
          },
        },
      ]
    );
  };

  const handleUpdate = async (formData: EncounterFormData) => {
    if (!selectedEncounter) return;
    
    setIsUpdating(true);
    try {
      const updated = await updateEncounter(selectedEncounter.id, formData);
      setEncounters(prev => prev.map(e => e.id === updated.id ? updated : e));
      setSelectedEncounter(updated);
      setShowEditForm(false);
    } catch (error) {
      Alert.alert('Error', 'Failed to update encounter');
    } finally {
      setIsUpdating(false);
    }
  };

  const renderEncounter = ({ item }: { item: Encounter }) => (
    <EncounterCard
      encounter={item}
      onPress={() => {
        setSelectedEncounter(item);
        setShowDetail(true);
      }}
      onDelete={() => handleDelete(item)}
    />
  );

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#2563eb" />
          <Text style={styles.loadingText}>Loading encounters...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>My Encounters</Text>
        <View style={styles.countBadge}>
          <Text style={styles.countText}>{filteredEncounters.length}</Text>
        </View>
      </View>

      {/* Search */}
      <SearchBar
        value={searchQuery}
        onChangeText={setSearchQuery}
        placeholder="Search by ID, notes, or location..."
      />

      {/* Filters */}
      <FilterChips
        selectedFilter={riskFilter}
        onFilterChange={setRiskFilter}
      />

      {/* Encounters List */}
      {filteredEncounters.length === 0 ? (
        <EmptyState
          icon="search-outline"
          title={encounters.length === 0 ? 'No encounters yet' : 'No matches found'}
          description={
            encounters.length === 0
              ? 'Start recording encounters to see them here'
              : 'Try adjusting your search or filters'
          }
          actionLabel={encounters.length === 0 ? 'Record Encounter' : undefined}
          onAction={encounters.length === 0 ? () => router.push('/(tabs)/new') : undefined}
        />
      ) : (
        <FlatList
          data={filteredEncounters}
          renderItem={renderEncounter}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#2563eb']} />
          }
        />
      )}

      {/* Detail Modal */}
      <Modal
        visible={showDetail}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => {
          setShowDetail(false);
          setSelectedEncounter(null);
        }}
      >
        {selectedEncounter && !showEditForm && (
          <EncounterDetail
            encounter={selectedEncounter}
            onEdit={() => setShowEditForm(true)}
            onDelete={() => handleDelete(selectedEncounter)}
            onClose={() => {
              setShowDetail(false);
              setSelectedEncounter(null);
            }}
          />
        )}
        {selectedEncounter && showEditForm && (
          <SafeAreaView style={styles.editContainer}>
            <View style={styles.editHeader}>
              <Text style={styles.editTitle}>Edit Encounter</Text>
            </View>
            <EncounterForm
              initialData={selectedEncounter}
              onSubmit={handleUpdate}
              onCancel={() => setShowEditForm(false)}
              isLoading={isUpdating}
            />
          </SafeAreaView>
        )}
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    fontSize: 15,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 8,
    gap: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#1e293b',
  },
  countBadge: {
    backgroundColor: '#2563eb',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  countText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#ffffff',
  },
  listContent: {
    padding: 16,
    paddingTop: 8,
  },
  editContainer: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  editHeader: {
    backgroundColor: '#ffffff',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  editTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1e293b',
    textAlign: 'center',
  },
});
