import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://wfzsqmbvlfshmwmnnhrn.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImJlZmQ4YTk2LTA5ZTMtNDBkNS05MGFhLWFlNDBkOGE5YzRkNyJ9.eyJwcm9qZWN0SWQiOiJ3ZnpzcW1idmxmc2htd21ubmhybiIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzY5MDUxMzAxLCJleHAiOjIwODQ0MTEzMDEsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.J6aWK2fluouvW1oVX-NOd4fsvs3J7IbQojs4uqupx9w';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };