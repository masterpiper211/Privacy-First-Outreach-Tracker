// Authentication service for outreach workers
import { supabase } from './supabase';
import { Worker } from './types';

export interface SignUpData {
  email: string;
  password: string;
  fullName: string;
  phone?: string;
  organization?: string;
}

export interface SignInData {
  email: string;
  password: string;
}

// Sign up a new worker
export const signUp = async (data: SignUpData): Promise<{ user: any; worker: Worker }> => {
  // Create auth user
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email: data.email,
    password: data.password,
  });

  if (authError) {
    throw new Error(authError.message);
  }

  if (!authData.user) {
    throw new Error('Failed to create user account');
  }

  // Create worker profile
  const { data: workerData, error: workerError } = await supabase
    .from('workers')
    .insert([{
      auth_user_id: authData.user.id,
      email: data.email,
      full_name: data.fullName,
      phone: data.phone || null,
      organization: data.organization || null,
    }])
    .select()
    .single();

  if (workerError) {
    console.error('Error creating worker profile:', workerError);
    throw new Error('Failed to create worker profile');
  }

  return { user: authData.user, worker: workerData };
};

// Sign in an existing worker
export const signIn = async (data: SignInData): Promise<{ user: any; worker: Worker }> => {
  const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
    email: data.email,
    password: data.password,
  });

  if (authError) {
    throw new Error(authError.message);
  }

  if (!authData.user) {
    throw new Error('Failed to sign in');
  }

  // Get worker profile
  const { data: workerData, error: workerError } = await supabase
    .from('workers')
    .select('*')
    .eq('auth_user_id', authData.user.id)
    .single();

  if (workerError || !workerData) {
    // Worker profile doesn't exist, create one
    const { data: newWorker, error: createError } = await supabase
      .from('workers')
      .insert([{
        auth_user_id: authData.user.id,
        email: data.email,
        full_name: data.email.split('@')[0], // Use email prefix as name
      }])
      .select()
      .single();

    if (createError) {
      throw new Error('Failed to create worker profile');
    }

    return { user: authData.user, worker: newWorker };
  }

  return { user: authData.user, worker: workerData };
};

// Sign out
export const signOut = async (): Promise<void> => {
  const { error } = await supabase.auth.signOut();
  if (error) {
    throw new Error(error.message);
  }
};

// Get current session
export const getSession = async () => {
  const { data: { session }, error } = await supabase.auth.getSession();
  if (error) {
    throw new Error(error.message);
  }
  return session;
};

// Get current user
export const getCurrentUser = async () => {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error) {
    return null;
  }
  return user;
};

// Get worker profile by auth user ID
export const getWorkerProfile = async (authUserId: string): Promise<Worker | null> => {
  const { data, error } = await supabase
    .from('workers')
    .select('*')
    .eq('auth_user_id', authUserId)
    .single();

  if (error) {
    console.error('Error fetching worker profile:', error);
    return null;
  }

  return data;
};

// Update worker profile
export const updateWorkerProfile = async (
  workerId: string, 
  updates: Partial<Pick<Worker, 'full_name' | 'phone' | 'organization'>>
): Promise<Worker> => {
  const { data, error } = await supabase
    .from('workers')
    .update({
      ...updates,
      updated_at: new Date().toISOString(),
    })
    .eq('id', workerId)
    .select()
    .single();

  if (error) {
    throw new Error('Failed to update profile');
  }

  return data;
};

// Listen for auth state changes
export const onAuthStateChange = (callback: (event: string, session: any) => void) => {
  return supabase.auth.onAuthStateChange(callback);
};
