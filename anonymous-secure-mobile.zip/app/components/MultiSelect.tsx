import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface MultiSelectProps {
  label: string;
  options: string[];
  selected: string[];
  onToggle: (option: string) => void;
  maxHeight?: number;
}

export const MultiSelect: React.FC<MultiSelectProps> = ({ 
  label, 
  options, 
  selected, 
  onToggle,
  maxHeight = 200,
}) => {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <ScrollView 
        style={[styles.optionsContainer, { maxHeight }]}
        nestedScrollEnabled
        showsVerticalScrollIndicator={true}
      >
        <View style={styles.optionsGrid}>
          {options.map((option) => {
            const isSelected = selected.includes(option);
            return (
              <TouchableOpacity
                key={option}
                style={[styles.option, isSelected && styles.optionSelected]}
                onPress={() => onToggle(option)}
                activeOpacity={0.7}
              >
                <View style={[styles.checkbox, isSelected && styles.checkboxSelected]}>
                  {isSelected && (
                    <Ionicons name="checkmark" size={12} color="#ffffff" />
                  )}
                </View>
                <Text 
                  style={[styles.optionText, isSelected && styles.optionTextSelected]}
                  numberOfLines={2}
                >
                  {option}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </ScrollView>
      {selected.length > 0 && (
        <Text style={styles.selectedCount}>
          {selected.length} selected
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 10,
  },
  optionsContainer: {
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    padding: 8,
  },
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 4,
  },
  optionSelected: {
    backgroundColor: '#eff6ff',
    borderColor: '#2563eb',
  },
  checkbox: {
    width: 18,
    height: 18,
    borderRadius: 4,
    borderWidth: 2,
    borderColor: '#cbd5e1',
    marginRight: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkboxSelected: {
    backgroundColor: '#2563eb',
    borderColor: '#2563eb',
  },
  optionText: {
    fontSize: 13,
    color: '#475569',
    flex: 1,
  },
  optionTextSelected: {
    color: '#1e40af',
    fontWeight: '500',
  },
  selectedCount: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 8,
    textAlign: 'right',
  },
});
