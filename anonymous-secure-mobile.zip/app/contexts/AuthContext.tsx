import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Worker, AuthState } from '../lib/types';
import { 
  signIn, 
  signUp, 
  signOut, 
  getCurrentUser, 
  getWorkerProfile,
  onAuthStateChange,
  SignInData,
  SignUpData,
} from '../lib/authService';

interface AuthContextType extends AuthState {
  login: (data: SignInData) => Promise<void>;
  register: (data: SignUpData) => Promise<void>;
  logout: () => Promise<void>;
  refreshWorker: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [state, setState] = useState<AuthState>({
    isAuthenticated: false,
    isLoading: true,
    user: null,
    worker: null,
  });

  // Check for existing session on mount
  useEffect(() => {
    checkAuth();

    // Listen for auth state changes
    const { data: { subscription } } = onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        const worker = await getWorkerProfile(session.user.id);
        setState({
          isAuthenticated: true,
          isLoading: false,
          user: session.user,
          worker,
        });
      } else if (event === 'SIGNED_OUT') {
        setState({
          isAuthenticated: false,
          isLoading: false,
          user: null,
          worker: null,
        });
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const checkAuth = async () => {
    try {
      const user = await getCurrentUser();
      if (user) {
        const worker = await getWorkerProfile(user.id);
        setState({
          isAuthenticated: true,
          isLoading: false,
          user,
          worker,
        });
      } else {
        setState({
          isAuthenticated: false,
          isLoading: false,
          user: null,
          worker: null,
        });
      }
    } catch (error) {
      console.error('Auth check error:', error);
      setState({
        isAuthenticated: false,
        isLoading: false,
        user: null,
        worker: null,
      });
    }
  };

  const login = async (data: SignInData) => {
    setState(prev => ({ ...prev, isLoading: true }));
    try {
      const { user, worker } = await signIn(data);
      setState({
        isAuthenticated: true,
        isLoading: false,
        user,
        worker,
      });
    } catch (error) {
      setState(prev => ({ ...prev, isLoading: false }));
      throw error;
    }
  };

  const register = async (data: SignUpData) => {
    setState(prev => ({ ...prev, isLoading: true }));
    try {
      const { user, worker } = await signUp(data);
      setState({
        isAuthenticated: true,
        isLoading: false,
        user,
        worker,
      });
    } catch (error) {
      setState(prev => ({ ...prev, isLoading: false }));
      throw error;
    }
  };

  const logout = async () => {
    setState(prev => ({ ...prev, isLoading: true }));
    try {
      await signOut();
      setState({
        isAuthenticated: false,
        isLoading: false,
        user: null,
        worker: null,
      });
    } catch (error) {
      setState(prev => ({ ...prev, isLoading: false }));
      throw error;
    }
  };

  const refreshWorker = async () => {
    if (state.user) {
      const worker = await getWorkerProfile(state.user.id);
      setState(prev => ({ ...prev, worker }));
    }
  };

  return (
    <AuthContext.Provider
      value={{
        ...state,
        login,
        register,
        logout,
        refreshWorker,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
