import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Encounter } from '../lib/types';
import { RiskBadge } from './RiskBadge';

interface EncounterDetailProps {
  encounter: Encounter;
  onEdit: () => void;
  onDelete: () => void;
  onClose: () => void;
}

export const EncounterDetail: React.FC<EncounterDetailProps> = ({
  encounter,
  onEdit,
  onDelete,
  onClose,
}) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const openInMaps = () => {
    if (encounter.latitude && encounter.longitude) {
      const url = Platform.select({
        ios: `maps:0,0?q=${encounter.latitude},${encounter.longitude}`,
        android: `geo:0,0?q=${encounter.latitude},${encounter.longitude}`,
        default: `https://www.google.com/maps?q=${encounter.latitude},${encounter.longitude}`,
      });
      Linking.openURL(url as string);
    }
  };

  const renderChips = (items: string[] | null, color: string) => {
    if (!items || items.length === 0) {
      return <Text style={styles.emptyText}>None recorded</Text>;
    }
    return (
      <View style={styles.chipsContainer}>
        {items.map((item, index) => (
          <View key={index} style={[styles.chip, { backgroundColor: `${color}15` }]}>
            <Text style={[styles.chipText, { color }]}>{item}</Text>
          </View>
        ))}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.closeBtn} onPress={onClose}>
          <Ionicons name="close" size={24} color="#64748b" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Encounter Details</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.actionBtn} onPress={onEdit}>
            <Ionicons name="pencil" size={20} color="#2563eb" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionBtn} onPress={onDelete}>
            <Ionicons name="trash" size={20} color="#ef4444" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.idSection}>
          <View style={styles.idContainer}>
            <Ionicons name="finger-print" size={28} color="#2563eb" />
            <Text style={styles.anonymousId}>{encounter.anonymous_id}</Text>
          </View>
          <RiskBadge level={encounter.risk_level} size="large" />
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Ionicons name="calendar-outline" size={18} color="#64748b" />
            <Text style={styles.sectionTitle}>Date & Time</Text>
          </View>
          <Text style={styles.dateText}>{formatDate(encounter.encounter_date)}</Text>
        </View>

        {(encounter.latitude || encounter.longitude || encounter.location_notes) && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Ionicons name="location-outline" size={18} color="#64748b" />
              <Text style={styles.sectionTitle}>Location</Text>
            </View>
            {encounter.location_notes && (
              <Text style={styles.locationNotes}>{encounter.location_notes}</Text>
            )}
            {encounter.latitude && encounter.longitude && (
              <TouchableOpacity style={styles.coordsBtn} onPress={openInMaps}>
                <Ionicons name="map-outline" size={16} color="#2563eb" />
                <Text style={styles.coordsText}>
                  {encounter.latitude.toFixed(6)}, {encounter.longitude.toFixed(6)}
                </Text>
                <Ionicons name="open-outline" size={14} color="#2563eb" />
              </TouchableOpacity>
            )}
          </View>
        )}

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Ionicons name="eye-outline" size={18} color="#64748b" />
            <Text style={styles.sectionTitle}>Observed Conditions</Text>
          </View>
          {renderChips(encounter.observed_conditions, '#7c3aed')}
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Ionicons name="hand-left-outline" size={18} color="#64748b" />
            <Text style={styles.sectionTitle}>Services Requested</Text>
          </View>
          {renderChips(encounter.services_requested, '#0891b2')}
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Ionicons name="arrow-forward-outline" size={18} color="#64748b" />
            <Text style={styles.sectionTitle}>Referrals Given</Text>
          </View>
          {renderChips(encounter.referrals_given, '#059669')}
        </View>

        {encounter.notes && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Ionicons name="document-text-outline" size={18} color="#64748b" />
              <Text style={styles.sectionTitle}>Notes</Text>
            </View>
            <Text style={styles.notesText}>{encounter.notes}</Text>
          </View>
        )}

        <View style={styles.metaSection}>
          <Text style={styles.metaText}>
            Created: {new Date(encounter.created_at).toLocaleString()}
          </Text>
          {encounter.updated_at !== encounter.created_at && (
            <Text style={styles.metaText}>
              Updated: {new Date(encounter.updated_at).toLocaleString()}
            </Text>
          )}
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#ffffff',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  closeBtn: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '600',
    color: '#1e293b',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
  },
  actionBtn: {
    padding: 8,
    backgroundColor: '#f8fafc',
    borderRadius: 8,
  },
  content: {
    flex: 1,
  },
  idSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    padding: 20,
    marginBottom: 12,
  },
  idContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  anonymousId: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1e293b',
    fontFamily: 'monospace',
  },
  section: {
    backgroundColor: '#ffffff',
    padding: 16,
    marginBottom: 8,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  dateText: {
    fontSize: 16,
    color: '#1e293b',
  },
  locationNotes: {
    fontSize: 15,
    color: '#1e293b',
    marginBottom: 10,
    lineHeight: 22,
  },
  coordsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#eff6ff',
    padding: 12,
    borderRadius: 10,
    gap: 8,
  },
  coordsText: {
    flex: 1,
    fontSize: 13,
    color: '#2563eb',
    fontFamily: 'monospace',
  },
  chipsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  chipText: {
    fontSize: 13,
    fontWeight: '500',
  },
  emptyText: {
    fontSize: 14,
    color: '#94a3b8',
    fontStyle: 'italic',
  },
  notesText: {
    fontSize: 15,
    color: '#374151',
    lineHeight: 24,
  },
  metaSection: {
    padding: 16,
    gap: 4,
  },
  metaText: {
    fontSize: 12,
    color: '#94a3b8',
  },
});
